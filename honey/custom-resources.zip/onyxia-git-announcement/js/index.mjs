// src/announcementState.ts
var STORAGE_KEY = "onyxia-git-announcement";
var initialState = {
  isLauncherNoticeDismissed: false,
  isReleaseDialogDismissed: false
};
var state = (() => {
  try {
    const serialized = localStorage.getItem(STORAGE_KEY);
    if (serialized === null) {
      return initialState;
    }
    return {
      ...initialState,
      ...JSON.parse(serialized)
    };
  } catch {
    return initialState;
  }
})();
var listeners = /* @__PURE__ */ new Set();
function getAnnouncementState() {
  return state;
}
function updateAnnouncementState(update) {
  if (Object.entries(update).every(
    ([key, value]) => state[key] === value
  )) {
    return;
  }
  state = { ...state, ...update };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
  }
  listeners.forEach((listener) => listener());
}
function subscribeToAnnouncementState(listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

// src/launcherDom.ts
var LAUNCHER_GIT_GROUP_TITLE_REGEXP = /^git\b/i;
var GIT_REPOSITORY_FIELD_SELECTOR = '[class*="FormFieldGroupComponent-field_gitRepository"]';
function isTopLevelAccordion(element) {
  return element.parentElement?.closest("[data-title]") === null;
}
function getTopLevelAccordion(element) {
  let accordion = element.closest("[data-title]");
  while (accordion !== null) {
    if (isTopLevelAccordion(accordion)) {
      return accordion;
    }
    accordion = accordion.parentElement?.closest("[data-title]") ?? null;
  }
  return null;
}
function getLauncherGitAccordion() {
  for (const element of document.querySelectorAll("[data-title]")) {
    if (LAUNCHER_GIT_GROUP_TITLE_REGEXP.test(element.dataset.title ?? "") && isTopLevelAccordion(element)) {
      return element;
    }
  }
  const gitRepositoryField = document.querySelector(GIT_REPOSITORY_FIELD_SELECTOR);
  if (gitRepositoryField === null) {
    return null;
  }
  return getTopLevelAccordion(gitRepositoryField);
}
function getLauncherFirstAccordionIfGitGroup() {
  if (getLauncherGitAccordion() === null) {
    return null;
  }
  for (const element of document.querySelectorAll("[data-title]")) {
    if (isTopLevelAccordion(element)) {
      return element;
    }
  }
  return null;
}
function scrollToAndOpenLauncherGitAccordion() {
  const accordion = getLauncherGitAccordion();
  if (accordion === null) {
    return;
  }
  accordion.scrollIntoView({ behavior: "smooth", block: "start" });
  const summary = accordion.querySelector(".MuiAccordionSummary-root");
  if (summary !== null && summary.getAttribute("aria-expanded") !== "true") {
    summary.click();
  }
}

// src/components.tsx
var LEARN_MORE_URL = "https://www.sspcloud.fr/document?path=SSPCloud%E2%90%A3Documentation%E2%80%BAUsing%E2%90%A3the%E2%90%A3Datalab%E2%80%BAVersion%E2%90%A3control";
var getAssetUrl = (fileName) => new URL(`../assets/${fileName}`, import.meta.url).href;
var isReleaseDialogClosed = false;
async function createComponents(ctx) {
  const [
    React,
    { tss },
    { routes, useRoute },
    { useLang, useTranslation },
    { Dialog },
    { Button },
    { useCoreState },
    { Icon },
    { IconButton },
    { getIconUrlByName }
  ] = await Promise.all([
    ctx.import("react"),
    ctx.import("tss"),
    ctx.import("ui/routes"),
    ctx.import("ui/i18n"),
    ctx.import("onyxia-ui/Dialog"),
    ctx.import("onyxia-ui/Button"),
    ctx.import("core"),
    ctx.import("onyxia-ui/Icon"),
    ctx.import("onyxia-ui/IconButton"),
    ctx.import("lazy-icons")
  ]);
  function useAnnouncementState() {
    return React.useSyncExternalStore(
      subscribeToAnnouncementState,
      getAnnouncementState
    );
  }
  function useIsFrench() {
    const { lang } = useLang();
    return lang === "fr";
  }
  function NewBadge() {
    const { classes } = useNewBadgeStyles();
    const isFrench = useIsFrench();
    return /* @__PURE__ */ React.createElement("span", { className: classes.root }, isFrench ? "Nouveau" : "New");
  }
  const useNewBadgeStyles = tss.withName("OnyxiaGitAnnouncementNewBadge").create(({ theme }) => ({
    root: {
      display: "inline-block",
      padding: theme.spacing({ topBottom: 1, rightLeft: 3 }),
      borderRadius: 100,
      backgroundColor: theme.colors.useCases.alertSeverity.info.main,
      // NOTE: Dark text in both modes, the info color is light.
      color: theme.colors.palette.dark.main,
      whiteSpace: "nowrap",
      verticalAlign: "middle",
      ...theme.typography.variants["label 2"].style
    }
  }));
  function usePreselectedForgeStatus() {
    const viewByFieldId = useCoreState(
      "gitRepositoryFieldUiController",
      "viewByFieldId"
    );
    const connectedForges = useCoreState("gitForgesManagement", "connectedForges");
    const disconnectedForges = useCoreState(
      "gitAccountUiController",
      "disconnectedForges"
    );
    for (const view of Object.values(viewByFieldId)) {
      if (view === void 0 || !("forges" in view.forgePicker)) {
        continue;
      }
      const { forges, forgeId } = view.forgePicker;
      const forge2 = forges.find((forge3) => forge3.forgeId === forgeId);
      if (forge2 === void 0) {
        continue;
      }
      if (!("issue" in forge2)) {
        return "connected";
      }
      switch (forge2.state) {
        case "to connect":
          return forge2.connectionMethod === "oauth" ? "sign in required" : "connection required";
        case "session expired":
          return "reconnect required";
        case "failed":
          return "connection error";
      }
    }
    if (connectedForges !== void 0 && connectedForges.length !== 0) {
      return "connected";
    }
    const forge = disconnectedForges?.[0];
    if (forge === void 0) {
      return void 0;
    }
    if (forge.error !== void 0) {
      return "connection error";
    }
    switch (forge.issue) {
      case "not connected":
        return forge.connectionMethod === "oauth" ? "sign in required" : "connection required";
      case "session expired":
        return "reconnect required";
      default:
        return "connection error";
    }
  }
  function LauncherGitAccordionStatus() {
    const status = usePreselectedForgeStatus();
    const { t } = useTranslation("GitForgeCard");
    const { classes, cx } = useLauncherGitAccordionStatusStyles();
    if (status === void 0) {
      return null;
    }
    const severity = (() => {
      switch (status) {
        case "connected":
          return "success";
        case "sign in required":
        case "connection required":
          return "neutral";
        case "reconnect required":
          return "warning";
        case "connection error":
          return "error";
      }
    })();
    return /* @__PURE__ */ React.createElement("span", { className: cx(classes.root, classes[`root_${severity}`]) }, /* @__PURE__ */ React.createElement("span", { className: cx(classes.dot, classes[`dot_${severity}`]) }), t(`chip ${status}`));
  }
  const useLauncherGitAccordionStatusStyles = tss.withName("OnyxiaGitAnnouncementLauncherGitAccordionStatus").create(({ theme }) => {
    const { alertSeverity } = theme.colors.useCases;
    return {
      root: {
        ...theme.typography.variants["caption"].style,
        display: "inline-flex",
        alignItems: "center",
        gap: theme.spacing(1),
        flexShrink: 0,
        whiteSpace: "nowrap",
        padding: theme.spacing({ topBottom: 1, rightLeft: 2 }),
        borderRadius: 100,
        color: theme.colors.useCases.typography.textPrimary
      },
      root_success: { backgroundColor: alertSeverity.success.background },
      // NOTE: Figma's surface-tertiary
      root_neutral: {
        backgroundColor: theme.colors.useCases.surfaces.surface2
      },
      root_warning: { backgroundColor: alertSeverity.warning.background },
      root_error: { backgroundColor: alertSeverity.error.background },
      dot: {
        width: 8,
        height: 8,
        borderRadius: "50%"
      },
      dot_success: { backgroundColor: alertSeverity.success.main },
      dot_neutral: {
        backgroundColor: theme.colors.useCases.typography.textSecondary
      },
      dot_warning: { backgroundColor: alertSeverity.warning.main },
      dot_error: { backgroundColor: alertSeverity.error.main }
    };
  });
  function LauncherGitNotice() {
    const { isLauncherNoticeDismissed } = useAnnouncementState();
    const { classes } = useLauncherGitNoticeStyles();
    const isFrench = useIsFrench();
    if (isLauncherNoticeDismissed) {
      return null;
    }
    const accountGitTabLink = routes.account({ tabId: "git" }).link;
    return /* @__PURE__ */ React.createElement("div", { className: classes.root, role: "note" }, /* @__PURE__ */ React.createElement(NewBadge, null), /* @__PURE__ */ React.createElement("div", { className: classes.text }, /* @__PURE__ */ React.createElement("span", { className: classes.title }, isFrench ? "Ce service peut d\xE9sormais utiliser vos comptes Git" : "This service can now use your Git accounts"), /* @__PURE__ */ React.createElement("span", { className: classes.subtitle }, isFrench ? /* @__PURE__ */ React.createElement(React.Fragment, null, "Connectez GitHub, GitLab, Forgejo ou Bitbucket depuis", " ", /* @__PURE__ */ React.createElement("a", { ...accountGitTabLink }, "votre compte"), ".") : /* @__PURE__ */ React.createElement(React.Fragment, null, "Connect GitHub, GitLab, Forgejo or Bitbucket from", " ", /* @__PURE__ */ React.createElement("a", { ...accountGitTabLink }, "your account"), "."))), /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        className: classes.goToAccordionButton,
        onClick: scrollToAndOpenLauncherGitAccordion
      },
      isFrench ? "Voir la configuration Git" : "See the Git settings",
      /* @__PURE__ */ React.createElement(
        Icon,
        {
          className: classes.goToAccordionButtonIcon,
          icon: getIconUrlByName("ArrowDownward")
        }
      )
    ), /* @__PURE__ */ React.createElement(
      IconButton,
      {
        icon: getIconUrlByName("Close"),
        "aria-label": isFrench ? "Masquer" : "Dismiss",
        onClick: () => updateAnnouncementState({ isLauncherNoticeDismissed: true })
      }
    ));
  }
  const useLauncherGitNoticeStyles = tss.withName("OnyxiaGitAnnouncementLauncherNotice").create(({ theme }) => {
    const { main: infoColor } = theme.colors.useCases.alertSeverity.info;
    return {
      root: {
        display: "flex",
        alignItems: "center",
        gap: theme.spacing(3),
        marginBottom: theme.spacing(3),
        padding: theme.spacing(3),
        borderRadius: 12,
        border: `1px solid ${infoColor}`,
        backgroundColor: `color-mix(in srgb, ${infoColor} 20%, transparent)`,
        color: theme.colors.useCases.typography.textPrimary
      },
      text: {
        flex: 1,
        minWidth: 0,
        display: "flex",
        flexDirection: "column"
      },
      title: {
        ...theme.typography.variants["label 1"].style,
        fontWeight: 600
      },
      subtitle: {
        ...theme.typography.variants["body 2"].style,
        "& a": {
          color: "inherit",
          whiteSpace: "nowrap"
        }
      },
      goToAccordionButton: {
        display: "inline-flex",
        alignItems: "center",
        gap: theme.spacing(1),
        padding: theme.spacing({ topBottom: 1, rightLeft: 3 }),
        border: "none",
        borderRadius: 100,
        cursor: "pointer",
        whiteSpace: "nowrap",
        // NOTE: Inverse colors, like the secondary action of the design system.
        backgroundColor: theme.colors.useCases.typography.textPrimary,
        color: theme.colors.useCases.surfaces.background,
        ...theme.typography.variants["label 2"].style
      },
      goToAccordionButtonIcon: {
        fontSize: 16,
        width: 16,
        height: 16
      }
    };
  });
  function ReleaseDialogCover() {
    const { classes } = useReleaseDialogCoverStyles();
    return /* @__PURE__ */ React.createElement("img", { className: classes.root, src: getAssetUrl("cover.webp"), alt: "" });
  }
  const useReleaseDialogCoverStyles = tss.withName("OnyxiaGitAnnouncementReleaseDialogCover").create(({ theme }) => ({
    root: {
      display: "block",
      width: "100%",
      height: "auto",
      aspectRatio: "6688 / 3764",
      objectFit: "cover",
      marginBottom: theme.spacing(4),
      borderRadius: 12
    }
  }));
  function ReleaseDialog() {
    const { isReleaseDialogDismissed } = useAnnouncementState();
    const { isUserLoggedIn } = useCoreState("userAuthentication", "main");
    const route = useRoute();
    const [isClosed, setIsClosed] = React.useState(isReleaseDialogClosed);
    const [doNotShowAgain, setDoNotShowAgain] = React.useState(false);
    const { classes } = useReleaseDialogStyles();
    const isFrench = useIsFrench();
    const close = () => {
      isReleaseDialogClosed = true;
      setIsClosed(true);
      if (doNotShowAgain) {
        updateAnnouncementState({ isReleaseDialogDismissed: true });
      }
    };
    const features = isFrench ? [
      "Connectez vos comptes GitHub, GitLab, Forgejo ou Bitbucket depuis votre compte.",
      "Au lancement d'un service, choisissez les d\xE9p\xF4ts et les branches \xE0 cloner.",
      "Vos identifiants Git sont fournis au service : git pull et git push fonctionnent directement."
    ] : [
      "Connect your GitHub, GitLab, Forgejo or Bitbucket accounts from your account page.",
      "When launching a service, pick the repositories and branches to clone.",
      "Your Git credentials are handed to the service: git pull and git push just work."
    ];
    return /* @__PURE__ */ React.createElement(
      Dialog,
      {
        isOpen: isUserLoggedIn && !isReleaseDialogDismissed && !isClosed,
        onClose: close,
        showCloseButton: true,
        maxWidth: false,
        muiDialogClasses: { paper: classes.paper },
        title: isFrench ? "Vos d\xE9p\xF4ts Git, directement dans vos services" : "Your Git repositories, right in your services",
        body: /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(ReleaseDialogCover, null), /* @__PURE__ */ React.createElement("ul", { className: classes.features }, features.map((feature) => /* @__PURE__ */ React.createElement("li", { key: feature }, feature)))),
        doNotShowNextTimeText: isFrench ? "Ne plus afficher ce message" : "Do not show this message again",
        onDoShowNextTimeValueChange: (doShowNextTime) => setDoNotShowAgain(!doShowNextTime),
        buttons: /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", href: LEARN_MORE_URL }, isFrench ? "En savoir plus" : "Learn more"), /* @__PURE__ */ React.createElement(
          Button,
          {
            onClick: () => {
              close();
              if (route.name === "account" && route.params.tabId === "git") {
                return;
              }
              routes.account({ tabId: "git" }).push();
            }
          },
          isFrench ? "Connecter mes comptes Git" : "Connect my Git accounts"
        ))
      }
    );
  }
  const useReleaseDialogStyles = tss.withName("OnyxiaGitAnnouncementReleaseDialog").create(({ theme }) => ({
    paper: {
      width: 717,
      maxWidth: "calc(100% - 32px)"
    },
    features: {
      margin: 0,
      paddingLeft: theme.spacing(4),
      display: "flex",
      flexDirection: "column",
      gap: theme.spacing(2)
    }
  }));
  return {
    ReleaseDialog,
    LauncherGitAccordionStatus,
    LauncherGitNotice
  };
}

// src/inject.ts
var domChangeListeners = /* @__PURE__ */ new Set();
function onDomChange(listener) {
  if (domChangeListeners.size === 0) {
    new MutationObserver(
      () => domChangeListeners.forEach((listener2) => listener2())
    ).observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["aria-expanded"]
    });
  }
  domChangeListeners.add(listener);
  listener();
}
function inject(params) {
  const { ctx, getTarget, position, hostStyle = {}, Component } = params;
  const { mount } = ctx.declareComponent(Component);
  let target_current = null;
  let host = void 0;
  onDomChange(() => {
    const target = getTarget();
    if (target !== target_current) {
      target_current = target;
      host?.remove();
      host = void 0;
      if (target === null) {
        mount(null);
        return;
      }
      host = document.createElement("span");
      host.setAttribute("data-onyxia-git-announcement", "");
      Object.assign(host.style, hostStyle);
    }
    if (target === null || host === void 0) {
      return;
    }
    switch (position) {
      case "prepend":
        if (host.parentElement !== target || host.previousSibling !== null) {
          target.prepend(host);
        }
        break;
      case "append":
        if (host.parentElement !== target || host.nextSibling !== null) {
          target.appendChild(host);
        }
        break;
      case "before":
        if (host.nextSibling !== target) {
          target.before(host);
        }
        break;
    }
    if (host.childElementCount === 0) {
      mount(host);
    }
  });
}

// src/main.ts
var ANNOUNCEMENT_END_DATE = /* @__PURE__ */ new Date("2027-01-31T23:59:59");
var onOnyxiaCtxReady_prev = window.onOnyxiaCtxReady;
window.onOnyxiaCtxReady = async (ctx) => {
  onOnyxiaCtxReady_prev?.(ctx);
  if (Date.now() > ANNOUNCEMENT_END_DATE.getTime()) {
    return;
  }
  const { getCore } = await ctx.import("core");
  const {
    functions: { gitAccountUiController }
  } = await getCore();
  if (!gitAccountUiController.isAvailable()) {
    return;
  }
  const { ReleaseDialog, LauncherGitAccordionStatus, LauncherGitNotice } = await createComponents(ctx);
  inject({
    ctx,
    getTarget: () => document.body,
    position: "append",
    hostStyle: { display: "none" },
    Component: ReleaseDialog
  });
  inject({
    ctx,
    getTarget: () => getLauncherGitAccordion()?.querySelector(".MuiAccordionSummary-content") ?? null,
    position: "append",
    hostStyle: { display: "inline-flex", alignSelf: "center" },
    Component: LauncherGitAccordionStatus
  });
  inject({
    ctx,
    getTarget: getLauncherFirstAccordionIfGitGroup,
    position: "before",
    hostStyle: { display: "block" },
    Component: LauncherGitNotice
  });
};
