<img src="%PUBLIC_URL%/custom-resources/release-note-s3-explorer/image-release-cover.png" style="margin-top:-30px" width="100%">  

# Nouvelle expérience de stockage de données dans Onyxia

Nous avons repensé l’expérience de stockage de données dans Onyxia afin de rendre l’accès aux données plus intuitif, plus efficace et mieux aligné avec le fonctionnement réel du stockage objet cloud.

**Cette version introduit des améliorations majeures autour de :**

* la navigation,

* l’accès aux données,

* les uploads,

* les favoris,

* et la visualisation des données.

L’objectif n’est pas seulement de moderniser l’interface, mais aussi de simplifier les workflows du quotidien tout en rendant les concepts S3 plus faciles à comprendre et à manipuler.

***

## Quelques mots sur S3

Onyxia s’appuie sur un stockage objet compatible S3 pour stocker et organiser les jeux de données, fichiers et résultats générés.

Contrairement aux systèmes de fichiers traditionnels, le stockage S3 repose sur :

* des buckets,

* des clés d’objets,

* des préfixes,

* et des profils d’accès.

Bien que ces concepts soient puissants et scalables, ils peuvent également rendre la navigation et la gestion des données plus difficiles à appréhender dans les workflows du quotidien.

Cette refonte vise à simplifier la manière dont les utilisateurs :

* naviguent dans les données,

* accèdent aux jeux de données fréquemment utilisés,

* uploadent et explorent des fichiers,

* et comprennent les contextes de stockage,

tout en restant cohérente avec le fonctionnement réel du stockage S3 sous-jacent.

L’objectif n’est pas d’exposer directement la complexité technique, mais de proposer une expérience de stockage plus claire, plus efficace et plus facile à comprendre pour tous les utilisateurs.

***

# Une nouvelle expérience de navigation centrée autour des chemins S3

![anim-ezgif.com-video-to-gif-converter.gif](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/anim-ezgif.com-video-to-gif-converter.gif)

Le chemin S3 devient désormais un point d’entrée central de la navigation.

La nouvelle barre d’URI S3 combine :

* une navigation par fil d’Ariane,

* un accès direct aux chemins S3,

* des suggestions d’autocomplétion,

* et des actions contextuelles.

Cela rend la navigation à la fois :

* exploratoire pour les utilisateurs moins techniques,

* et directe et efficace pour les workflows avancés.

## Améliorations

* Navigation directe via des chemins `s3://...`

* Meilleure visibilité des buckets et des préfixes

* Navigation plus rapide dans des structures profondes

* Actions contextuelles directement depuis la barre de navigation

<!--![S3 URI Bar](./images/s3-uri-bar.gif)-->

***

# Des favoris pensés pour les workflows du quotidien

![ImageRelease.png](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/ImageRelease.png)

Les chemins fréquemment utilisés peuvent désormais être enregistrés comme favoris pour un accès rapide.

Les favoris permettent de réduire les navigations répétitives et de rendre les jeux de données importants plus facilement accessibles au quotidien.

L’interface distingue désormais :

* les favoris personnels,

* et les points d’entrée de stockage par défaut ou organisationnels.

## Améliorations

* Accès rapide aux chemins fréquemment utilisés

* Meilleure visibilité des jeux de données importants

* Points d’entrée dédiés directement depuis l’accueil du stockage

* Interface de favoris plus légère et plus claire

<!--![Bookmarks](./images/bookmarks.gif)-->

***

# Une expérience d’upload plus claire avec un suivi global des tâches

![ImageRelease2.png](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/ImageRelease2.png)

**L’upload de fichiers est désormais plus simple et plus facile à suivre.**

Les uploads ne sont plus liés à un contexte local unique dans l’interface : un système global de suivi des uploads permet désormais de visualiser les tâches en cours depuis n’importe où dans l’expérience de stockage.

Inspirée des interfaces modernes de stockage cloud, cette amélioration apporte davantage de clarté et réduit les frictions lors des workflows d’import de données.

## Améliorations

* Suivi global des uploads

* Visibilité plus claire de la progression

* Interactions d’upload simplifiées

* Meilleur feedback lors des tâches longues

<!--![Uploads](./images/uploads.gif)-->

***

# Visualisation des données directement depuis l’interface de stockage

Les données peuvent désormais être prévisualisées directement depuis l’interface de stockage.

Cela réduit les changements de contexte entre les outils et rend les workflows d’exploration plus fluides et plus intuitifs.

## Améliorations

* Prévisualisation directe des données

* Compréhension plus rapide du contenu des jeux de données

* Réduction des frictions liées à la navigation et aux outils

* Workflows de stockage plus unifiés

<!--![Data Preview](./images/data-preview.gif)-->

***

# Améliorations UX supplémentaires

Cette version introduit également de nombreuses améliorations UX et UI plus petites à travers toute l’expérience de stockage :

* davantage d’actions contextuelles,

* une hiérarchie visuelle plus claire,

* des workflows de sélection améliorés,

* une gestion des profils plus compréhensible,

* et une meilleure cohérence globale de l’interface.

***

# Pourquoi cette refonte ?

Le stockage objet S3 ne fonctionne pas comme un système de fichiers traditionnel.

Cette refonte vise à :

* mieux refléter le fonctionnement réel de S3,

* éviter des abstractions trompeuses,

* tout en conservant une expérience accessible et intuitive.

L’objectif est d’aider progressivement les utilisateurs à :

* comprendre les structures de stockage,

* naviguer plus efficacement,

* et manipuler les données avec davantage de confiance.

***

# Prochaines étapes

Cette refonte pose également les bases des futures fonctionnalités autour de :

* du partage,

* de la gestion des accès publics/privés,

* des liens d’accès temporaires,

* des liens d’upload,

* et des workflows collaboratifs autour des données.

D’autres améliorations et itérations sont déjà prévues.

[Retour au nouvel explorateur de fichiers](/s3)