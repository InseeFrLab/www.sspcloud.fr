<img src="%PUBLIC_URL%/custom-resources/release-note-s3-explorer/image-release-cover.png" width="100%">  


## Nouvelle expérience de stockage de données dans Onyxia

Nous avons repensé l’expérience de stockage de données dans Onyxia afin de rendre l’accès aux données plus intuitif, plus efficace et mieux aligné avec le fonctionnement réel du stockage d’objets dans le cloud.

[En savoir plus](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/fr.md)