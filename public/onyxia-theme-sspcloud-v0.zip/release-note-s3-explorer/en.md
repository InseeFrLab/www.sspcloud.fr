<img src="%PUBLIC_URL%/custom-resources/release-note-s3-explorer/image-release-cover.png" style="margin-top:-30px" width="100%">  

# New Data Storage Experience in Onyxia

We redesigned the data storage experience in Onyxia to make data access more intuitive, more efficient, and better aligned with how cloud object storage actually works.

**This release introduces major improvements around:**

* navigation,

* data access,

* uploads,

* bookmarks,

* and data visualization.

The goal is not only to modernize the interface, but also to simplify everyday workflows while making S3 concepts easier to understand and manipulate.

***

## A few words about S3

Onyxia relies on S3-compatible object storage to store and organize datasets, files, and generated outputs.

Unlike traditional file systems, S3 storage is based on:

* buckets,

* object keys,

* prefixes,

* and access profiles.

While these concepts are powerful and scalable, they can also make navigation and data management harder to understand in everyday workflows.

This redesign aims to simplify how users:

* navigate through data,

* access frequently used datasets,

* upload and explore files,

* and understand storage contexts,

while staying consistent with how S3 storage actually behaves underneath.

The goal is not to expose technical complexity directly, but to create a clearer, more efficient, and easier to understand storage experience for all users.

***

# A new navigation experience centered around S3 paths

![anim-ezgif.com-video-to-gif-converter.gif](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/anim-ezgif.com-video-to-gif-converter.gif)

The S3 path has become a central navigation entry point.

The new S3 URI bar combines:

* breadcrumb navigation,

* direct S3 path access,

* autocomplete suggestions,

* and contextual actions.

This makes navigation both:

* exploratory for less technical users,

* and direct and efficient for advanced workflows.

## Improvements

* Navigate directly using `s3://...` paths

* Better visibility of buckets and prefixes

* Faster navigation through deep structures

* Contextual actions directly from the navigation bar

<!--![S3 URI Bar](./images/s3-uri-bar.gif)-->

***

# Bookmarks designed for everyday workflows

![ImageRelease.png](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/ImageRelease.png)

Frequently used paths can now be saved as bookmarks for quick access.

Bookmarks help reduce repetitive navigation and make important datasets easier to access daily.

The interface now distinguishes:

* personal bookmarks,

* and organization/default storage entry points.

## Improvements

* Quick access to frequently used paths

* Better visibility of important datasets

* Dedicated entry points directly from the storage home

* Cleaner and lighter bookmark interface

<!--![Bookmarks](./images/bookmarks.gif)-->

***

# A clearer upload experience with global task tracking

![ImageRelease2.png](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/ImageRelease2.png)

**Uploading files is now simpler and easier to follow.**

Uploads are no longer tied to a single local context inside the interface: a global upload tracking system now provides visibility on ongoing tasks from anywhere in the storage experience.

Inspired by modern cloud storage interfaces, this improves clarity and reduces friction during data import workflows.

## Improvements

* Global upload tracking

* Clearer progress visibility

* Simplified upload interactions

* Better feedback during long-running tasks

<!--![Uploads](./images/uploads.gif)-->

***

# Data visualization directly from the storage interface

Data can now be previewed directly from the storage interface.

This reduces context switching between tools and makes exploration workflows more fluid and intuitive.

## Improvements

* Direct data preview

* Faster understanding of dataset content

* Reduced navigation and tooling friction

* More unified storage workflows

<!--![Data Preview](./images/data-preview.gif)-->

***

# Additional UX improvements

This release also introduces many smaller UX and UI improvements across the storage experience:

* more contextual actions,

* cleaner visual hierarchy,

* improved selection workflows,

* clearer profile handling,

* and better consistency across the interface.

***

# Why this redesign?

S3 object storage does not behave like a traditional file system.

This redesign aims to:

* better reflect how S3 actually works,

* avoid misleading abstractions,

* while keeping the experience accessible and intuitive.

The objective is to progressively help users:

* understand storage structures,

* navigate more efficiently,

* and manipulate data more confidently.

***

# Next steps

This redesign also lays the foundation for upcoming features around:

* sharing,

* public/private access management,

* temporary access links,

* upload links,

* and collaborative data workflows.

More improvements and iterations are already planned.

[Back to the new file explorer](/s3)
