
export async function run(onyxia){

    if (!onyxia.core.states.userAuthentication.getMain().isUserLoggedIn) {
        return;
    }

    const getIsS3Explorer = () =>
        onyxia.route.name === "s3Explorer" || onyxia.route.name === "s3Explorer_root";

    if (!getIsS3Explorer()) {
        await new Promise(resolve => {
            onyxia.addEventListener(eventName => {
                if (eventName === "route changed" && getIsS3Explorer()) {
                    resolve();
                }
            });
        });
    }

    {
        const KEY = "is-release-note-s3-shown";

        if (localStorage.getItem(KEY)) {
            return;
        }
        localStorage.setItem(KEY, "true");
    }

    onyxia.evtGlobalDialog.postAsyncOnceHandled({
        body: {
            en: `/custom-resources/release-note-s3-explorer/dialog-body-en.md`,
            fr: `/custom-resources/release-note-s3-explorer/dialog-body-fr.md`
        }
    });

}