<img src="%PUBLIC_URL%/custom-resources/release-note-s3-explorer/image-release-cover.png" width="100%">  


## New Data Storage Experience in Onyxia

We redesigned the data storage experience in Onyxia to make data access more intuitive, more efficient, and better aligned with how cloud object storage actually works.

[Learn more](%PUBLIC_URL%/custom-resources/release-note-s3-explorer/en.md)