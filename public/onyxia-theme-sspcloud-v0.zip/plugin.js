

import { run as run_release_note_s3_explorer } from "./release-note-s3-explorer/modal.js";

window.addEventListener("onyxiaready", ()=> {
    run_release_note_s3_explorer(onyxia);
});