
(async ()=> {
    await import("./onyxia-explain-with-ai/js/index.mjs");
    await import("./onyxia-git-announcement/js/index.mjs");
})();

export {};
