
(async ()=> {
    await import("./onyxia-ai-announcement/js/index.mjs");
    await import("./onyxia-explain-with-ai/js/index.mjs");
})();

export {};
