// The AI announcement plugin registers itself with `window.onOnyxiaCtxReady`,
// importing it is enough. https://github.com/onyxia-datalab/onyxia-ai-annoncement
import "./onyxia-ai-announcement/js/index.mjs";
